package com.example.aplicatie_sma;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import com.example.aplicatie_sma.R;




import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NoteAdapter noteAdapter;
    private List<Note> noteList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Inițializare listă
        noteList = new ArrayList<>();
        noteList.add(new Note("Don't forget", "11:42 AM", "#E3F2FD"));
        noteList.add(new Note("Reminder", "Oct 27", "#F8BBD0"));
        noteList.add(new Note("Shopping list", "Oct 27", "#C8E6C9"));
        noteList.add(new Note("Business plan", "Oct 27", "#FFF9C4"));

        // Setare adapter
        noteAdapter = new NoteAdapter(noteList);
        recyclerView.setAdapter(noteAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_sort, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 2131230890: // Înlocuiește cu valoarea reală a R.id.sort_by_color
                sortByColor();
                return true;
            case 2131230891: // Înlocuiește cu valoarea reală a R.id.sort_by_date
                sortByDate();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void sortByColor() {
        Collections.sort(noteList, new Comparator<Note>() {
            @Override
            public int compare(Note o1, Note o2) {
                return o1.getColor().compareTo(o2.getColor());
            }
        });
        noteAdapter.notifyDataSetChanged();
    }

    private void sortByDate() {
        Collections.sort(noteList, new Comparator<Note>() {
            @Override
            public int compare(Note o1, Note o2) {
                return o1.getDate().compareTo(o2.getDate());
            }
        });
        noteAdapter.notifyDataSetChanged();
    }
}