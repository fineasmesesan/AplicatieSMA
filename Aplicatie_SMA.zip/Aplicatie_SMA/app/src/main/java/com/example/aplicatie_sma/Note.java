package com.example.aplicatie_sma;

public class Note {
    private String title;
    private String date;
    private String color;

    public Note(String title, String date, String color) {
        this.title = title;
        this.date = date;
        this.color = color;
    }

    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public String getColor() {
        return color;
    }
}

